import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SettingsChangepasswordPage } from './settings-changepassword';

@NgModule({
  declarations: [
    SettingsChangepasswordPage,
  ],
  imports: [
    IonicPageModule.forChild(SettingsChangepasswordPage),
  ],
})
export class SettingsChangepasswordPageModule {}
