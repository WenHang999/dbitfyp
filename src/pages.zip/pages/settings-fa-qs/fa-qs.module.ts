import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FaQsPage } from './fa-qs';

@NgModule({
  declarations: [
    FaQsPage,
  ],
  imports: [
    IonicPageModule.forChild(FaQsPage),
  ],
})
export class FaQsPageModule {}
